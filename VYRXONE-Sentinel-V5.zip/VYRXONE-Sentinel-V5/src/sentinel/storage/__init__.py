"""Local SQLite persistence."""
