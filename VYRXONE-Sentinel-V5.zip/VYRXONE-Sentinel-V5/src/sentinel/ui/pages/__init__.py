"""Control-panel pages."""
